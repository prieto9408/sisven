﻿using AccesoDatos;
using Entidades;
using LogicaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SisVen
{
    /// <summary>
    /// Interaction logic for FormPersona.xaml
    /// </summary>
    public partial class FormPersona : Window
    {
        public FormPersona()
        {
            InitializeComponent();
            sexoCbx.Items.Add("Masculino") ;
            sexoCbx.Items.Add("Femenino");
            ListarPersona();


        }

        public void clearEntidades() {
            Persona persona = new Persona();    
            nombreTxt.Text = persona.Nombre ;
            apPaternoTxt.Text = persona.ApellidoPaterno;
            apMaternoTxt.Text = persona.ApellidoMaterno;
            nroDocTxt.Text = persona.NroDocumento;
            fechNacPkr.Text = persona.FechaNacimiento;
            direccionTxt.Text = persona.Direccion;
            
       


        }
        public void llenarCampos(Persona persona)
        {
       
            nombreTxt.Text = persona.Nombre;
            
            apPaternoTxt.Text = persona.ApellidoPaterno;
            apMaternoTxt.Text = persona.ApellidoMaterno;
            nroDocTxt.Text = persona.NroDocumento;
            fechNacPkr.Text = persona.FechaNacimiento;
            direccionTxt.Text = persona.Direccion;




        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Persona persona = new Persona();

            persona.Nombre=nombreTxt.Text;
            persona.ApellidoPaterno = apPaternoTxt.Text;
            persona.ApellidoMaterno = apMaternoTxt.Text;
            persona.NroDocumento = nroDocTxt.Text;
            persona.Sexo = sexoCbx.SelectedItem.ToString();
            persona.FechaNacimiento = fechNacPkr.Text.ToString();
            persona.Direccion = direccionTxt.Text;
            persona.FechaCreacion = DateTime.Now;
            persona.UsuarioCreacion = "ADMIN";

            PersonaLN personaLN = new PersonaLN();
            personaLN.InsertarPersonaLN(persona);
            clearEntidades();
            MessageBox.Show("SE GRABO CORRECTAMENTE");

        }

        public void ListarPersona() {


            PersonaLN personaLN = new PersonaLN();
            ListaPersonaDtg.ItemsSource = personaLN.ListarPersonaLN();

        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ListaPersonaDtg_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("SE hizo doble click");
        }

        private void ListaPersonaDtg_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            Persona persona = new Persona();
            persona =  (Persona)ListaPersonaDtg.CurrentItem;
            llenarCampos(persona);
            
        }
    }
}
