﻿using AccesoDatos;
using Entidades;
using LogicaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Linq;

namespace SisVen
{
    /// <summary>
    /// Interaction logic for FormPersona.xaml
    /// </summary>
    public partial class FormPersona : Window
    {
         List<Persona> lispe = new List<Persona>();
        public FormPersona()
        {
           
            InitializeComponent();
            sexoCbx.Items.Add( "MASCULINO") ;
            sexoCbx.Items.Add("FEMENINO");
            ListarPersona();


        }

        public void clearEntidades() {
            Persona persona = new Persona();    
            nombreTxt.Text = persona.Nombre ;
            apPaternoTxt.Text = persona.ApellidoPaterno;
            apMaternoTxt.Text = persona.ApellidoMaterno;
            nroDocTxt.Text = persona.NroDocumento;
            fechNacPkr.Text = persona.FechaNacimiento;
            direccionTxt.Text = persona.Direccion;
          
            
       


        }
        public void llenarCampos(Persona persona)
        {
       
            nombreTxt.Text = persona.Nombre;
            sexoCbx.Text =  persona.Sexo.ToUpper();
            apPaternoTxt.Text = persona.ApellidoPaterno;
            apMaternoTxt.Text = persona.ApellidoMaterno;
            nroDocTxt.Text = persona.NroDocumento;
            fechNacPkr.Text = persona.FechaNacimiento;
            direccionTxt.Text = persona.Direccion;




        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Persona persona = new Persona();

            persona.Nombre=nombreTxt.Text;
            persona.ApellidoPaterno = apPaternoTxt.Text;
            persona.ApellidoMaterno = apMaternoTxt.Text;
            persona.NroDocumento = nroDocTxt.Text;
            persona.Sexo = sexoCbx.SelectedItem.ToString();
            persona.FechaNacimiento = fechNacPkr.Text.ToString();
            persona.Direccion = direccionTxt.Text;
            persona.FechaCreacion = DateTime.Now;
            persona.UsuarioCreacion = "ADMIN";

            PersonaLN personaLN = new PersonaLN();
            personaLN.InsertarPersonaLN(persona);
            clearEntidades();
            MessageBox.Show("SE GRABO CORRECTAMENTE");

        }

        public void ListarPersona() {


            PersonaLN personaLN = new PersonaLN();
            ListaPersonaDtg.ItemsSource = personaLN.ListarPersonaLN();
            lispe = (List<Persona>)ListaPersonaDtg.ItemsSource;

        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ListaPersonaDtg_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("SE hizo doble click");
        }

        private void ListaPersonaDtg_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            Persona persona = new Persona();
            persona =  (Persona)ListaPersonaDtg.CurrentItem;
            llenarCampos(persona);
            
        }

        private void buscarBtn_Click(object sender, RoutedEventArgs e)
        {
           
           
            if (filtroTxt.Text == "")
            {
                ListaPersonaDtg.ItemsSource = lispe;
            }
            else {
                var lispe2 = (List<Persona>)ListaPersonaDtg.ItemsSource;
                var filtrado = from persona in lispe2
                               where persona.Nombre == filtroTxt.Text
                               select persona;

                ListaPersonaDtg.ItemsSource = filtrado;
            }
            
        }
    }
}
