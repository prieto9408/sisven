﻿using AccesoDatos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio
{
    public  class PersonaLN
    {
        public void InsertarPersonaLN(Persona persona) 
        { 
            PersonaAD personaAD = new PersonaAD();

            personaAD.InsertarPersonaAD(persona);
        }
    }
}
