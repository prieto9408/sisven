﻿using AccesoDatos;
using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogicaNegocio
{
    public  class PersonaLN
    {
        public int InsertarPersonaLN(Persona persona) 
        { 
            PersonaAD personaAD = new PersonaAD();

           return  personaAD.InsertarPersonaAD(persona);
        }
        public List<Persona> ListarPersonaLN() 
        {
            PersonaAD personaAD = new PersonaAD();
            return personaAD.ListarPersonaAD();
        }
    }
}
