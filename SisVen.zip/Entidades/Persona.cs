﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Persona
    {
   
        public int IdPersona { get; set; }
        public string Nombre { get; set; }
        public string ApellidoPaterno { get; set; }
        public string ApellidoMaterno { get; set; }
        public string NroDocumento { get; set; }
        public string Sexo { get; set; }
        public string FechaNacimiento { get; set; }
        public string Direccion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string UsuarioCreacion { get; set; }

        public Persona() {
            Nombre = "";
            ApellidoPaterno = "";
            ApellidoMaterno = "";
            NroDocumento = "";
            Sexo = "";
            FechaNacimiento = "";
            FechaCreacion = DateTime.Now;
            UsuarioCreacion = "";
        }
    }
}
