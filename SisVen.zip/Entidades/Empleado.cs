﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public  class Empleado
    {
        public int IdEmpleado { get; set; }
        public string Cargo { get; set; }
        public string OFicina { get; set; }
        public decimal Salario { get; set; }
        public string Email{ get; set; }
        public DateTime FechaCreacion { get; set; }
        public string UsuarioCreacion{ get; set; }

    }
}
