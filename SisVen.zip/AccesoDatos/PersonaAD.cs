﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace AccesoDatos
{
    public class PersonaAD
    {
        string conectionString = ConfigurationManager.ConnectionStrings["conx"].ConnectionString;

        public int InsertarPersonaAD(Persona persona) 
        {
            int personaid = 0;
            using (SqlConnection sqlConnection = new SqlConnection(conectionString))
            {
       
                using (SqlCommand sqlCommand = new SqlCommand("InsertarPersona", sqlConnection)) 
                { 
                    sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;

                    sqlCommand.Parameters.AddWithValue("@Nombre", persona.Nombre);
                    sqlCommand.Parameters.AddWithValue("@ApellidoPaterno", persona.ApellidoPaterno);
                    sqlCommand.Parameters.AddWithValue("@ApellidoMaterno", persona.ApellidoMaterno);
                    sqlCommand.Parameters.AddWithValue("@NroDocumento", persona.NroDocumento);
                    sqlCommand.Parameters.AddWithValue("@Sexo", persona.Sexo);
                    sqlCommand.Parameters.AddWithValue("@FechaNacimiento", persona.FechaNacimiento);
                    sqlCommand.Parameters.AddWithValue("@Direccion", persona.Direccion);
                    sqlCommand.Parameters.AddWithValue("@FechaCreacion", persona.FechaCreacion);
                    sqlCommand.Parameters.AddWithValue("@UsuarioCreacion", persona.UsuarioCreacion);
                    sqlConnection.Open();
                    personaid = Convert.ToInt32( sqlCommand.ExecuteScalar());
                    sqlConnection.Close();
                }

                return personaid;
            }   
        }

        public List<Persona> ListarPersonaAD() 
        {
            List<Persona> lista = new List<Persona>();
    

            using (SqlConnection sqlConnection = new SqlConnection(conectionString)) {
                using (SqlCommand  sqlCommand   = new SqlCommand("ListarPersona", sqlConnection)) {

                    sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                    sqlConnection.Open();
                    SqlDataReader reader = sqlCommand.ExecuteReader();
                    while (reader.Read())
                    {
                        Persona persona = new Persona();
                        persona.IdPersona = Convert.ToInt32(reader["IdPersona"]);
                        persona.Nombre = Convert.ToString(reader["Nombre"]);
                        persona.ApellidoPaterno = Convert.ToString(reader["ApellidoPaterno"]);
                        persona.ApellidoMaterno = Convert.ToString(reader["ApellidoMaterno"]);
                        persona.NroDocumento = Convert.ToString(reader["NroDocumento"]);
                        persona.Sexo = Convert.ToString(reader["Sexo"]);
                        persona.FechaNacimiento = Convert.ToString(reader["FechaNacimiento"]);
                        persona.Direccion = Convert.ToString(reader["Direccion"]);
                        persona.FechaCreacion = Convert.ToDateTime(reader["FechaCreacion"]);
                        persona.UsuarioCreacion = Convert.ToString(reader["UsuarioCreacion"]);
                        lista.Add(persona);

                    }
                }
            }
                return lista;
        
        }

    }
}
