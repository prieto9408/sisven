﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos
{
    public class EmpleadoAD
    {
        string conectionString = ConfigurationManager.ConnectionStrings["conx"].ConnectionString;

        public void InsertarEmpleado(int IdPersona,Empleado empleado) 
        {
            using (SqlConnection sqlConnection = new SqlConnection(conectionString))
            {

                using (SqlCommand sqlCommand = new SqlCommand("InertarEmpleado", sqlConnection))
                {
                    sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;

                    sqlCommand.Parameters.AddWithValue("@IdEmpleado", empleado.IdEmpleado);
                    sqlCommand.Parameters.AddWithValue("@Cargo", empleado.Cargo);
                    sqlCommand.Parameters.AddWithValue("@OFicina", empleado.OFicina);
                    sqlCommand.Parameters.AddWithValue("@Salario", empleado.Salario);
                    sqlCommand.Parameters.AddWithValue("@Email", empleado.Email);
                    sqlCommand.Parameters.AddWithValue("@FechaCreacion", empleado.FechaCreacion);
                    sqlCommand.Parameters.AddWithValue("@UsuarioCreacion", empleado.UsuarioCreacion);
                    sqlConnection.Open();
                    sqlCommand.ExecuteNonQuery();
                    sqlConnection.Close();
                }


            }

        }
    }
}
